/***Written by Nnabuife Chidozie***/
function START_GAME(){ 

var energy,money,xp,food, education,work,market,main,cook,buy,buyRecipes,foodMenu, buyMeals,recipes,meals,clsbtn, clsbtn3,clsbtn4,eduMenu,enrollSchool,learn,teach,ufo, employer, employee,workMenu, workAsEmployee, workAsEmployer,achievement,empl,header, more,moreBtn,help,helpBtn,difficulty, difficultyBtn;


function id(elementToGet){
return document.getElementById(elementToGet) }

header = id("header");
help = id("help");
helpBtn = id("helpBtn");
moreBtn = id("moreBtn");
 more= id("more");
 difficultyBtn = id("difficultyBtn");
difficulty= id("difficulty");



energy = id("energy");
money = id("money");
xp = id("xp");
achievement = id("achievement");
var respects=id("respects");
var empl= id("empl");

food = id("food");
education = id("education");
work = id("work");
market = id("market");
main = id("main");
//food variables
kitchen = id("kitchen");
foodMenu = id("foodMenu");
buy = id("buy");
cook = id("cook");
buy = id("buy");
meals = id("meals");
buyMeals = id("buyMeals");
buyRecipes = id("buyRecipes");
recipes= id("recipes");
clsbtn = id("clsbtn");

//kitchen inventory
pizza = id("pizza");
cake= id("cake");
bread = id("bread");
meat = id("meat");
rice = id("rice");

//education variables
enrollSchool = id("enrollSchool");
eduMenu = id("eduMenu");
learn = id("learn");
teach = id("teach");
clsbtn3 = id("clsbtn3");
ufo = id("ufo");




//work
employee = id("employee");
workAsEmployee= id("workAsEmployee");
workMenu = id("workMenu");
workAsEmployer = id("workAsEmployer");
employer= id("employer")
clsbtn4 = id("clsbtn4");

msg={
lowMoney: "Insufficient money",lowXp: "Insufficient experience",
lowEnergy:"Insufficient energy"
}


function hide(){
return main.style.display = "none";
}
function show(){
return main.style.display = "block";
}

var home = id("home");
helpBtn.onclick=function (){ home.style.display="none"
help.style.display="block"; 
 }

var dif= id("dif");

difficultyBtn.onclick=function (){
 
dif.style.display="block" 
 }

id("difBack").onclick=function (){
home.style.display="block"
dif.style.display="none";
 }

moreBtn.onclick=function (){ home.style.display="none"
more.style.display="block"; 
 }

id("closeHelp").onclick=function (){ 
this.parentElement.style.display="none";
home.style.display="block";
}

id("closeMore").onclick=function (){ 
this.parentElement.style.display="none";
home.style.display="block";
}


id("easy").onclick=function (){
header.style.display='block';
show();
dif.style.display='none';
home.style.display='none';
money.innerText=70;
xp.innerText=70;
energy.innerText=70;
 }

id("medium").onclick=function (){
header.style.display='block';
show();
dif.style.display='none';
home.style.display='none';
money.innerText=10;
xp.innerText=10;
energy.innerText=50;
 }

id("hard").onclick=function (){
header.style.display='block';
show();
dif.style.display='none';
home.style.display='none';
money.innerText=30;
xp.innerText=0;
energy.innerText=25;
 }


id("exit").onclick=function (){ 
hide();
home.style.display='block';
header.style.display="none";
}

//food
meals.onclick=function (){ 
 kitchenMenu.style.display="none";
 buyRecipes.style.display="none"; 
 recipes.classList.remove('rec');
 meals.classList.add("rec")
 buyMeals.style.display="block"
 }
 recipes.onclick=function (){
 recipes.classList.add("rec")
 buyRecipes.style.display="block";
meals.classList.remove('rec');
 buyMeals.style.display="none"
 }
 //closebtn
clsbtn.onclick=function (){ 
show();
this.parentElement.style.display="none";
recipes.classList.add("rec")
}


 buy.onclick=function (){ 
 hide()
recipes.classList.add("rec");
meals.classList.remove("rec")
 foodMenu.style.display="block";
 }

cook.onclick=function (){
hide();
 kitchenMenu.style.display="block";
foodMenu.style.display="none";
 }
clsbtn2.onclick=function (){ 
show();
this.parentElement.style.display="none";
}




//buy Recipes
var shopList=document.getElementsByClassName("r1");

for(let i = 0;i<shopList.length;i++){
shopList[i].onclick=function (){
 if(parseInt(money.innerText)>=this.id){
 if(this.id==23){
  pizza.innerText=parseInt(pizza.innerText)+1;
money.innerText-=parseInt(this.id);
 } 
 if(this.id==20){
  cake.innerText=parseInt(cake.innerText)+1;
money.innerText-=parseInt(this.id); 
  }
  if(this.id==17){
  rice.innerText=parseInt(rice.innerText)+1;
  money.innerText-=parseInt(this.id);
  }
  if(this.id==13){
  bread.innerText=parseInt(bread.innerText)+1;
  money.innerText-=parseInt(this.id);
  }
  if(this.id==10){
  meat.innerText=parseInt(meat.innerText)+1;
  money.innerText-=parseInt(this.id);
  }
  }
 else{
 alert(msg.lowMoney)
 }  
 }
 }//end of buy recipes
 
 
// eat meal
var purchasedFood = document.getElementsByClassName("r2");
for(let i=0; i < purchasedFood.length;i++){

purchasedFood[i].onclick=function(){ 

if(this.innerText!=0){
 if(this.id=="pizza"){
   this.innerText=parseInt(this.innerText)-parseInt(1);
energy.innerText=parseInt(energy.innerText)+parseInt(23);
  xp.innerText=parseInt(xp.innerText)+parseInt(4)
   }
   if(this.id=="cake"){
     this.innerText=parseInt(this.innerText)-parseInt(1);
   energy.innerText=parseInt(energy.innerText)+parseInt(20);
xp.innerText=parseInt(xp.innerText)+parseInt(3)
   }
   if(this.id=="rice"){
     this.innerText=parseInt(this.innerText)-parseInt(1);
   energy.innerText=parseInt(energy.innerText)+parseInt(17);
xp.innerText=parseInt(xp.innerText)+parseInt(2)
   }
   if(this.id=="bread"){
     this.innerText=parseInt(this.innerText)-parseInt(1)
   energy.innerText=parseInt(energy.innerText)+parseInt(10);
xp.innerText=parseInt(xp.innerText)+parseInt(1)
   }
   if(this.id=="meat"){
   this.innerText=parseInt(this.innerText)-parseInt(1)  
   energy.innerText=parseInt(energy.innerText)+parseInt(10)
xp.innerText=parseInt(xp.innerText)+parseInt(0)
   }
}
else{
 alert("You dont have the recipe for "+this.id)
}
}//end of eat
}//end for eat


//buyMeal and eat
var fastMeal = document.getElementsByClassName("r3");
 for(let i= 0;i<fastMeal.length;i++){
fastMeal[i].onclick=function (){
   if(parseInt(money.innerText)>=this.id){
   if(this.id=="30"){
 money.innerText= parseInt(money.innerText) - this.id;
xp.innerText= parseInt(xp.innerText) -4;
energy.innerText = parseInt(energy.innerText) + parseInt(25);
    }
    if(this.id=="25"){
    money.innerText= parseInt(money.innerText) - this.id;
    xp.innerText= parseInt(xp.innerText) -3;
    energy.innerText = parseInt(energy.innerText) + parseInt(20);
    }
    
    if(this.id=="20"){
    money.innerText= parseInt(money.innerText) - this.id;
    xp.innerText= parseInt(xp.innerText) -3;
    energy.innerText = parseInt(energy.innerText) + parseInt(15);
    }
    if(this.id=="15"){
    money.innerText= parseInt(money.innerText) - this.id;
    xp.innerText= parseInt(xp.innerText) -2;
    energy.innerText = parseInt(energy.innerText) + parseInt(10);
    }
    if(this.id=="10"){
    money.innerText= parseInt(money.innerText) - this.id;
    xp.innerText= parseInt(xp.innerText) -1;
    energy.innerText = parseInt(energy.innerText) + parseInt(5);
    }
   } //end of all if  
   else{
   alert(msg.lowMoney)
   } 
 }//end of for loop
 }//end of fast  meal
 
 
 
 //enrol school 
 clsbtn3.onclick=function (){
 show();
 this.parentElement.style.display='none';
 }
 
learn.onclick=function (){
 hide();
 eduMenu.style.display="block";
 }

var lv1,lv2,lv3,lv4,l5,lv6;


 var schoolBtn= document.getElementsByClassName("k1");
for(let i=0;i<schoolBtn.length;i++){
lv1=schoolBtn[0];
lv2=schoolBtn[1];
lv3=schoolBtn[2];
lv4=schoolBtn[3];
lv5=schoolBtn[4];


lv2.style.display="none"
lv3.style.display="none"
lv4.style.display="none"
lv5.style.display="none"


 schoolBtn[i].onclick=function (){
   if( parseInt(money.innerText)>=this.id &&  parseInt(energy.innerText)>=50  ){

if(this.id==50 && parseInt(energy.innerText)>=50 ){

alert("Congratulations for completing your basic education!");
lv1.style.display="none"
lv2.style.display="block"
    money.innerText=parseInt(money.innerText) -parseInt(this.id);
    energy.innerText=parseInt(energy.innerText) -parseInt(25);
setInterval(function (){ 
 xp.innerText=parseInt(xp.innerText)+parseInt(1);
},1000)
  }
    if(this.id==200 && parseInt(energy.innerText)>=50 ){
alert("Congratulations for completing your high school education!");
lv2.style.display="none"
lv3.style.display="block"
    money.innerText=parseInt(money.innerText) -parseInt(100);
    energy.innerText=parseInt(energy.innerText) -parseInt(50);
 setInterval(function (){ 
 xp.innerText=parseInt(xp.innerText)+parseInt(2);
 },1000)
      }
      
      if(this.id==1000 && parseInt(energy.innerText)>=500 ){
alert("Congratulations for completing your college education!");
lv3.style.display="none";
lv4.style.display="block";
      money.innerText=parseInt(money.innerText) -parseInt(1000);
      energy.innerText=parseInt(energy.innerText) -parseInt(500);
 setInterval(function (){ 
 xp.innerText=parseInt(xp.innerText)+parseInt(3);
 },1000)
      }
    
    if(this.id==7000 && parseInt(energy.innerText)>=2900 ){
lv4.style.display="none";
lv5.style.display="block";

alert("Congratulations for completing your higher education !");
    money.innerText=parseInt(money.innerText) -parseInt(7000);
    energy.innerText=parseInt(energy.innerText) -parseInt(2900);
setInterval(function (){ 
xp.innerText=parseInt(xp.innerText)+parseInt(5);
},1000);
    } 
      
    if(this.id==10000 && parseInt(xp.innerText)>=5000 ){  
lv5.style.display="none";
alert("You are now professor, your XP increases periodically\nYou won't be enrolling into the lower education levels 💡💡");   
//  eduMenu.style.display='none';
//show();
id("showEdu").style.display='block'; 
alert("The commissioner for education awarded you with 100000 💰 ");   
money.innerText=parseInt(money.innerText) +100000; 
    setInterval(function (){
    respects.innerText=parseInt(respects.innerText)+parseInt(5);

    energy.innerText=parseInt(energy.innerText)-parseInt(5);
    },2000)
       
    
setInterval(function (){
 respects.innerText=parseInt(respects.innerText)+parseInt(2);
 xp.innerText=parseInt(xp.innerText)+parseInt(100);
 },500);

setInterval(function (){
 money.innerText=parseInt(money.innerText)+parseInt(5000);
 
 },2000)
       
 }
 }//end of all if      
   else{
   alert(
  msg.lowMoney +" Or energy to study")
   }
 }//end nof school loop
}// endenroll school 
 
 //work menu 
 //switch career modes
var noWork= id("noWork");
var ws=id("emp");
 work.onclick=function (){ 
 workMenu.style.display='block';
hide();
noWork.innerText=parseInt(emp.innerText);

 }
 
clsbtn4.onclick=function (){ 
show();
this.parentElement.style.display='none';
 
 }
 
 employee.onclick=function (){
workAsEmployer.style.display="none";
workAsEmployee.style.display="block";
employer.classList.remove('rec');
employee.classList.add('rec')
 }
 
 employer.onclick=function (){
 workAsEmployee.style.display="none";
workAsEmployer.style.display="block";
 employee.classList.remove('rec');
 employer.classList.add('rec');
 }
 
 //earn from work
var workNow= document.getElementsByClassName("w");
 for(let i=0;i<workNow.length;i++){
workNow[i].onclick=function (){ 
if(parseInt(energy.innerText)>=this.id){
  if(this.id==50){
respects.innerText=parseInt(respects.innerText)-parseInt(2);  
money.innerText=parseInt(money.innerText) +50;
energy.innerText=parseInt(energy.innerText) -15;
xp.innerText=parseInt(xp.innerText) +2;
    }
    if(this.id==60 && parseInt(xp.innerText)>=120){
 respects.innerText=parseInt(respects.innerText)-parseInt(5);
    money.innerText=parseInt(money.innerText) +150;
    energy.innerText=parseInt(energy.innerText) -30;
    xp.innerText=parseInt(xp.innerText) +4;
    }
       
       if(this.id==70 && parseInt(xp.innerText)>=200){
 respects.innerText=parseInt(respects.innerText)+parseInt(3);
       money.innerText=parseInt(money.innerText) +300;
       energy.innerText=parseInt(energy.innerText) -50;
       xp.innerText=parseInt(xp.innerText) +6;
       }
       
       if(this.id==80 && parseInt(xp.innerText)>=500){
 respects.innerText=parseInt(respects.innerText)+parseInt(2);
       money.innerText=parseInt(money.innerText) +700;
       energy.innerText=parseInt(energy.innerText) -30;
       xp.innerText=parseInt(xp.innerText) +11;
       }
       
       if(this.id==100 && parseInt(xp.innerText)>=10000){
 alert('Congratulations, you have been given the position of the CEO.\nYour earnings increases over time.\nYou can no longer apply for lower positions.') ;
workAsEmployee.style.display="none";
workAsEmployer.style.display="block";
employee.style.display="none"
   setInterval(function (){ 
respects.innerText=parseInt(respects.innerText)+parseInt(5);   
      money.innerText=parseInt(money.innerText) +100000;
       energy.innerText=parseInt(energy.innerText) +100;
       xp.innerText=parseInt(xp.innerText) +20;
       },1000)
       } 
                          
} //if apexends
else{
alert(msg.lowEnergy)
}
}
 }//for loop work ends
 
 //Achievements
 var achievementList= id("achievementList");
id("clsbtn5").onclick=function (){ 
show();
this.parentElement.style.display='none';
}
achievement.onclick=function (){
 hide();
achievementList.style.display='block';

setInterval(function (){ 
id("en").innerText= parseInt(energy.innerText);
id("exp").innerText= parseInt(xp.innerText);
id("net").innerText= parseInt(money.innerText);

},1000);

 }
//end achieve

//life style
id("clsbtn6").onclick=function (){ 
show();
this.parentElement.style.display='none'
}

var lifeMenu=id("lifeMenu");
var lifeStyle=id("lifeStyle");
lifeStyle.onclick=function (){ hide();

lifeMenu.style.display='block'; 
 }


//working as employerrrr
var noWork = id("noWork");
var employWorkers=id("employWorkers") ;
var buyCompany =id("buyCompany");
var buildCompany=document.getElementById("buildCompany");
var emp =id("emp");
employWorkers.onclick=function (){ 
if(parseInt(money.innerText)>=5000 && parseInt(xp.innerText)>=10000){
money.innerText=parseInt(money.innerText)-5000;
noWork.innerText=parseInt(noWork.innerText)+1;
var emp =id("emp");
emp.innerText=parseInt(emp.innerText)+parseInt(1);
empl.innerText=parseInt(empl.innerText)+parseInt(1);
}
else{
alert(msg.lowMoney +" or experiences");
}
}
 
 
buildCompany.onclick=function (){
 if(parseInt(money.innerText)>=500000 && parseInt(emp.innerText)>=50){
this.parentElement.style.display='none';
alert("congratulations,\nYou have built this company.\nYour earning now increases periodically 🤝 ")
 emp.innerText= parseInt(emp.innerText)-100;
setInterval(function (){ 
 energy.innerText= parseInt(energy.innerText)-100;
 money.innerText= parseInt(money.innerText)+parseInt(1000000);
},5000)
 }
 else{
 alert(msg.lowMoney +" Or low number of idle employees");
 }
 }
 
 buyCompany.onclick=function (){
 if(parseInt(money.innerText)>=1000000 && parseInt(emp.innerText)>=100){
 this.parentElement.style.display='none';
 alert("congratulations,\nYou have purchased this company.\nYour earning now increases periodically 🤝 ")
 emp.innerText= parseInt(emp.innerText)-70;
 setInterval(function (){ 
 energy.innerText= parseInt(energy.innerText)-120;
 money.innerText= parseInt(money.innerText)+parseInt(100000);
 },1000)
 }
 else{
 alert(msg.lowMoney +" Or low number of idle employees");
 }
 }
 
var ownHouse=false; 
//marriage.
var marry = id("marry");
var wife=id("wife");
var kids = id("kids");

marry.onclick=function (){
 if(parseInt(money.innerText)>=10000 && parseInt(xp.innerText)>=20000 && ownHouse==true){
kids.innerText=0;
this.parentElement.style.display='none';
wife.innerText="Married"
alert(" 🤵👰 Congratulations on your successful Marriage.\nNote!!\nGoing into marriage will take some energy, money and XP periodically.\nhaving kids will even take more.");
setInterval(function (){ 
kids.innerText = parseInt(kids.innerText)+parseInt(1);
energy.innerText= parseInt(energy.innerText)-(2000*kids.innerText);
money.innerText= parseInt(money.innerText)-parseInt(50000*kids.innerText);
xp.innerText= parseInt(xp.innerText)-(100*kids.innerText);
respects.innerText= parseInt(respects.innerText)+(2*kids.innerText);
},30000)

setInterval(function (){ 
energy.innerText= parseInt(energy.innerText)-1000;
money.innerText= parseInt(money.innerText)-parseInt(50000);
xp.innerText= parseInt(xp.innerText)-3000;
respects.innerText= parseInt(respects.innerText)+(40);
},5000);

 }
 else{
 alert("You must own a house first and You must also have 100 Million 💰 and 200k XP" )
 }
  }//marriage ends
 
 //house
 var house=id("house");
var smallHouse=false;
 house.onclick=function (){ 
 if(parseInt(money.innerText)>=30000){
smallHouse=true;
alert("Purchase successful !");
this.parentElement.style.display="none";
ownHouse=true;
money.innerText= parseInt(money.innerText)-parseInt(30000);
setInterval(function (){ 
respects.innerText= parseInt(respects.innerText)+(50);
energy.innerText= parseInt(energy.innerText)+parseInt(3000);
},5000);

 }
 
 else{
 alert(msg.lowMoney);
 }
 
 }
 //house ends
 
 //mansion 
 
var mansion = id("mansion");
mansion.onclick=function (){ 
if(parseInt(money.innerText) >=3000000 && smallHouse==true){
this.parentElement.style.display='none';
alert("purchas successful !")
money.innerText= parseInt(money.innerText)-parseInt(3000000);
setInterval(function(){ 
respects.innerText= parseInt(respects.innerText)+(100);
energy.innerText= parseInt(energy.innerText)+parseInt(5000);
},5000);
}
else{
alert("You must first have a small house.\nAlso make sure you have 3Million 💰 ");
}
}; //mansion ends


//vehicles
var vehicle = id("vehicles");
var bike = id("bike");
bike.onclick=function (){ 
if(parseInt(money.innerText)>=100000){
vehicles.innerText=parseInt(vehicles.innerText) + 1;
money.innerText=parseInt(money.innerText) - 100000;
respects.innerText=parseInt(respects.innerText) + 500;
setInterval(function (){ 
xp.innerText=parseInt(xp.innerText) - 1;
money.innerText=parseInt(money.innerText) - 5000;
},11000)
}
else{
alert(msg.lowMoney)
}
}

var car = id("car");
car.onclick=function (){ 
if(parseInt(money.innerText)>=500000){
vehicles.innerText=parseInt(vehicles.innerText) + 1;
money.innerText=parseInt(money.innerText) - 500000;
respects.innerText=parseInt(respects.innerText) + 2000;
setInterval(function (){ 
xp.innerText=parseInt(xp.innerText) - 1;
},20000)
}
else{
alert(msg.lowMoney)
}
}

//pets
var pets = id('pets');
var cat = id("cat");
cat.onclick=function (){ 
if(parseInt(money.innerText)>=30000){
pets.innerText=parseInt(pets.innerText) + 1;
money.innerText=parseInt(money.innerText) - 30000;
respects.innerText=parseInt(respects.innerText) + 50;
setInterval(function (){ 
xp.innerText=parseInt(xp.innerText) - 1;
},20000)
}
else{
alert(msg.lowMoney)
}
}
var dog = id("dog");
dog.onclick=function (){ 
if(parseInt(money.innerText)>=50000){
pets.innerText=parseInt(pets.innerText) + 1;
money.innerText=parseInt(money.innerText) - 50000;
respects.innerText=parseInt(respects.innerText) + 80;
setInterval(function (){ 
xp.innerText=parseInt(xp.innerText) - 1;
},20000)
}
else{
alert(msg.lowMoney)
}
}
 var helicopter = id("helicopter");
 helicopter.onclick=function (){ 
 if(parseInt(money.innerText)>=3000000){
 vehicles.innerText=parseInt(vehicles.innerText) + 1;
 money.innerText=parseInt(money.innerText) - 3000000;
 setInterval(function (){ 
xp.innerText=parseInt(xp.innerText) - 1;
respects.innerText=parseInt(respects.innerText) + 6;
 },2000);
 }
 else{
 alert(msg.lowMoney)
 }
 }
 
 var panda = id("panda");
 panda.onclick=function (){ 
 if(parseInt(money.innerText)>=30000000){
 pets.innerText=parseInt(pets.innerText) + 1;
 money.innerText=parseInt(money.innerText) - 30000000;
 setInterval(function (){ 
 respects.innerText=parseInt(respects.innerText) +2000;
 },25000)
 }
 else{
 alert(msg.lowMoney)
 }
 }
 
 //hotel

 var hotel = id("hotel");
 hotel.onclick=function (){ 
 if(parseInt(money.innerText)>=300000000){
this.parentElement.style.display='none';
alert("Purchase successful");
alert("You made a great investment choice here!");
 money.innerText=parseInt(money.innerText) - 300000000;
 setInterval(function (){ 
 money.innerText=parseInt(money.innerText) +5000; 
 respects.innerText=parseInt(respects.innerText) +100;
 },4000)
 }
 else{
 alert(msg.lowMoney)
 }
 }
 
 //stade
 var stadium = id("stadium");
 stadium.onclick=function (){ 
 if(parseInt(money.innerText)>=800000000){
this.parentElement.style.display='none';
 alert("Glad you decided to invest into sports! ");
 money.innerText=parseInt(money.innerText) - 800000000;
 setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) +1000; 
 money.innerText=parseInt(money.innerText) +10000; 
 respects.innerText=parseInt(respects.innerText) +200;
 },4000)
 }
 else{
 alert(msg.lowMoney)
 }
 }
 
 //olympic

var olympic = id("olympic");
olympic.onclick=function (){ 
if(parseInt(money.innerText)>=30000000000){
this.parentElement.style.display='none';
alert("The whole world speaks about your progress.\ncongratulations for making your nation great ! ");
money.innerText=parseInt(money.innerText) - 30000000000;
setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) +2000;
xp.innerText=parseInt(xp.innerText) +5000;
money.innerText=parseInt(money.innerText) +50000; 
respects.innerText=parseInt(respects.innerText) +1500;
},3000)
}
else{
alert(msg.lowMoney)
}
}
 

//port 
var airport= id("airport");
airport.onclick=function (){ 
if(parseInt(money.innerText)>=3000000000){
this.parentElement.style.display='none';
alert("Congratulations on your outstanding success.\nYour Airport has been built !");
money.innerText=parseInt(money.innerText)-3000000000;
setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) +10000;
xp.innerText=parseInt(xp.innerText) +2500;
money.innerText=parseInt(money.innerText) +20000; 
respects.innerText=parseInt(respects.innerText) +800;
},4000)
}
else{
alert(msg.lowMoney)
}
}

//cyber
 var cyber= id("cyber");
 cyber.onclick=function (){ 
 if(parseInt(money.innerText)>=10000000000){
this.parentElement.style.display='none';
 
 alert("Your name is all over the internet!!!\nYour Twitter followers is 1million+");
 money.innerText=parseInt(money.innerText)-10000000000;
 setInterval(function (){ 
  energy.innerText=parseInt(energy.innerText) +1000;
 xp.innerText=parseInt(xp.innerText) +3000;
 money.innerText=parseInt(money.innerText) +1000; 
 respects.innerText=parseInt(respects.innerText) +3000;
 },3000)
 }
 else{
 alert(msg.lowMoney)
 }
 }
  var coronaDead= false;
var covid= id("covid");

covid.onclick=function (){ 
coronaDead=true;
if(parseInt(money.innerText)>=500000000000){
this.parentElement.style.display='none';
alert("Thank you for joining hands to fight covid19 cure.\nPresidentship contestant form is out now, you should go check!!!")

money.innerText=parseInt(money.innerText)-500000000000;
setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) +10000;
xp.innerText=parseInt(xp.innerText) +30000;
money.innerText=parseInt(money.innerText) +10000; 
respects.innerText=parseInt(respects.innerText) +30000;
},1000)
}
else{
alert(msg.lowMoney);
}
}
//president
var president= id("president");
president.onclick=function (){ 
if(coronaDead==true && parseInt(xp.innerText)>=10000000000 && parseInt(money.innerText)>=30000000000){
this.parentElement.style.display='none';
alert("The whole citizens love you.\nCongratulations, you just won the presidency sit of your country.\nWho knows you would from a security personnel to becoming the president of your country.\nYou are a role model to every living being in the world !!!");
money.innerText=parseInt(money.innerText)-30000000000;
setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) -1000;
xp.innerText=parseInt(xp.innerText) +30000;
money.innerText=parseInt(money.innerText) +10000; 
respects.innerText=parseInt(respects.innerText) +30000;
},1000)
}
else{
alert("Make sure you have enough money and respects!\nElection will take place when Covid19 cure is found.\ncome on help fight this virus!!!")
}
}

//nasa
var city= false;
var nasa= id("nasa");
nasa.onclick=function (){ 
if(parseInt(money.innerText)>=100000000000){
city=true;
this.parentElement.style.display='none';
alert("Because of you, project-TN-O16 is successful!\nYour name is already written on the moon!");
money.innerText=parseInt(money.innerText)-100000000000;
setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) +1000;
xp.innerText=parseInt(xp.innerText) +30000;
money.innerText=parseInt(money.innerText) +10000; 
respects.innerText=parseInt(respects.innerText) +30000;
},1000)
}
else{
alert("Make sure you have enough money!")
}
}
//Citizenship
var citizen= id("citizen");
cz= id("citizenShip");
citizen.onclick=function (){
if(parseInt(money.innerText)>=1000000000000 && city==true){
cz.innerText=0;
this.parentElement.style.display='none';
alert("Because of your contribution to the whole world, all the countries in the world made you a citizen of theirs.\nCONGRATULATIONS for becoming a citizen of 182+ countries!!!");
alert("Your are now the strongest living creature in thw whole world");
id("final").style.display="block";
hide();
lifeMenu.style.display="none";
money.innerText=parseInt(money.innerText)-1000000000000;
cz.innerText=parseInt(cz.innerText)+182;
setInterval(function (){ 
 energy.innerText=parseInt(energy.innerText) -1000;
xp.innerText=parseInt(xp.innerText) +30000;
money.innerText=parseInt(money.innerText) +10000; 
respects.innerText=parseInt(respects.innerText) +30000;
},1000)
}
else{
alert("You should help Nasa complete their pending project, also make to sure have 1trillion in your bank account")
}
}

//
id("end").onclick=function (){
 this.parentElement.style.display="none";
show();
 }


}//end

