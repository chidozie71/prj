
/***Developed by Nnabuife Chidozie***/

window.onload=function() {

var sn = document.getElementsByTagName('input')[0];
sn.disabled='true';
var code=document.getElementsByTagName('input')[1];


var unit=document.getElementsByTagName('input')[2];

var grade=document.getElementsByTagName('input')[3];
var btn=document.getElementsByTagName('button')[0]

var btn2=document.getElementsByTagName('button')[1]


var ol=document.querySelector('ol');

//trigger
var totalCreditUnit=0
var addUnit=0
var serial=1
btn.addEventListener('click', function() {

newSn=document.createElement('input');
newSn.className='sn';
newSn.disabled='false';


newCode=document.createElement('input');
newCode.value=code.value;
newCode.className="courseCode";
newCode.disabled='true'
newCode.style.margin='5px';
var newUnit=document.createElement('input');
newUnit.value=unit.value;
newUnit.className="courseUnit";
newUnit.style.margin='5px';
newUnit.style.marginLeft='0px'

newUnit.type="button";

var newGrade=document.createElement('input');
newGrade.value=grade.value;
newGrade.type='button';
newGrade.className="courseGrade";
newGrade.style.marginLeft='0px'

var li=document.createElement('li');
li.className='mylist'





if(grade.value==''|| unit.value==''){
alert("Empty Field Detected !")
}else{

switch(grade.value.toUpperCase()){
case 'A':
grade.value=4.00
break;
case 'AB':
grade.value=3.50
break;
case 'B':
grade.value=3.00
break;
case 'BC':
grade.value=2.50
break;
case 'CD':
grade.value=2.00
break;
case 'F':
grade.value=0.00
break;
default:
grade.value=0.00
break;
}




addUnit+=parseInt(unit.value);
totalCreditUnit+=unit.value*grade.value;
newSn.value=serial++;
li.appendChild(newSn)
li.appendChild(newCode);
li.appendChild(newUnit);
li.appendChild(newGrade);
li.className='zoom'
li.classList.add('mylist');
ol.appendChild(li);
sn.value='';
code.value='';
unit.value='';
grade.value='';
btn2.style.display='block';
}

})//entry


btn2.addEventListener('click',function() {
var modal=document.getElementById("modal");
var output=document.querySelector('h2');
var output2=document.querySelector('h3')
var total=(totalCreditUnit/addUnit).toFixed(2);
output.innerText=total;
if(total>=3.50){
output2.innerText="Distinction"
output2.style.color="#097F4B";
output.style.color="#097F4B"
}
else if(total>=3.00 && total<=3.49){
output2.innerText='Upper credit'
output2.style.color="#0B6207";
output.style.color="#0B6207"

}

else if(total>=2.50 && total<=2.99){
output2.innerText='lower credit'
output2.style.color="orange";
output.style.color="orange"
}

else if(total>=2.00 && total<=2.49){
output2.innerText='pass'
output2.style.color="#8D3D38";
output.style.color="#8D3D38"
}

else if(total>=0.00 && total<=1.99){
output2.innerText='fail'
output2.style.color="#FF1A00";
output.style.color="#FF1A00"
}


modal.style.display='block';

})





}//window